let slideIndex = 0;
const slideInterval = 2000; // 2 seconds
let slideTimer;

function showSlides() {
    let slides = document.getElementsByClassName("slide");

    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";  // Hide all slides
    }

    slides[slideIndex].style.display = "block";  // Show the current slide
}

function startSlideShow() {
    slideTimer = setInterval(() => {
        slideIndex++;
        if (slideIndex >= document.getElementsByClassName("slide").length) {
            slideIndex = 0;  // Loop back to the first slide
        }
        showSlides();
    }, slideInterval);
}

function stopSlideShow() {
    clearInterval(slideTimer);
}

function prevSlide() {
    let slides = document.getElementsByClassName("slide");
    stopSlideShow();  // Stop automatic slideshow
    slideIndex--;
    if (slideIndex < 0) {
        slideIndex = slides.length - 1;  // Loop to the last slide
    }
    showSlides();
    startSlideShow();  // Restart automatic slideshow
}

function nextSlide() {
    let slides = document.getElementsByClassName("slide");
    stopSlideShow();  // Stop automatic slideshow
    slideIndex++;
    if (slideIndex >= slides.length) {
        slideIndex = 0;  // Loop back to the first slide
    }
    showSlides();
    startSlideShow();  // Restart automatic slideshow
}

// Initialize the slideshow when the page loads
window.onload = function() {
    showSlides();  // Show the initial slide
    startSlideShow();  // Start automatic slideshow
};
